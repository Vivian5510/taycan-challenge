# Taycan Submission Candidate

This archive follows the contest code-delivery shape: complete C++ implementation, CMake configuration, and this README. It is a source candidate, not a passing submission.

## Status

- Engine base: F2/FASTER, pinned at `research/FASTER`.
- Linux durability candidate: F2 `data-log`; the data log uses F2 HybridLog records and a checksummed commit footer before advancing the durable frontier and acknowledging writes.
- Compaction: requires `TAYCAN_F2_DURABLE_COMPACTION=ON`; the full official compaction and crash matrix has not been completed for this package snapshot.
- Checkpoint: `CreateCheckpoint` remains unsupported and is an optional scoring feature.
- Performance: the latest native Linux diagnostic was 300,000 keys, 32 callers, 4 GiB, with a 47,300 ops/s median. The contest load gate is 2e8 keys and at least 60,000 ops/s. This diagnostic does not pass that gate.
- Official 2e8-key load, both 4/16 GiB 600-second mixed workloads, and all required final correctness cases have not been verified on this exact archive.

Do not treat this archive as accepted or fully evaluated.

## Build

The build is intended for Linux x86_64 and requires an offline-provisioned toolchain and system libraries: CMake 3.24+, GCC 8.3+, Python 3.6+, oneTBB, libaio, libuuid, and RocksDB headers/library (used for CRC32C). GoogleTest 1.14 and gflags 2.2.2 source archives are bundled under `code/taycan_participant_sdk/third_party/`. No dependency download is performed by this project at configure time.

From this directory:

```sh
cmake -S code/taycan_participant_sdk -B /tmp/taycan-build -DCMAKE_BUILD_TYPE=Release -DTAYCAN_BUILD_PERF_BENCHMARKS=ON -DTAYCAN_F2_SYNC_STRATEGY=data-log -DTAYCAN_F2_DURABLE_COMPACTION=ON -DTAYCAN_F2_DATA_SEGMENT_BITS=23
cmake --build /tmp/taycan-build --parallel
```

Run the public correctness harness from this directory:

```sh
python3 script/taycan/tests/run_correctness.py --build-dir /tmp/taycan-build --results-dir /var/tmp/taycan-correctness
```

The archive was assembled without running this build. The listed system libraries and final Linux x86_64 configuration still need verification in the target evaluation environment.

## Layout

- `code/faster-native-adapter/`: F2 integration and persistence implementation.
- `code/taycan_participant_sdk/`: contest interface, CMake project, public C++ tests, benchmark workload, and bundled test dependencies.
- `script/taycan/`: correctness and performance runners.
- `research/FASTER/cc/src/`: pinned upstream FASTER/F2 source used by the build.
- `research/rocksdb-v8.9.1/`: CRC32C header dependency and upstream license notices.

The separate architecture design PDF is delivered beside this archive as `taycan_design_document.pdf`.
