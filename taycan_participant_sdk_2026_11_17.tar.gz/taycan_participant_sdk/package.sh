#!/usr/bin/env bash
# Package sources only; build and test separately with CMake/Python.
set -euo pipefail

root="$(cd "$(dirname "$0")" && pwd)"
if [[ $# != 1 || ( "$1" != engine && "$1" != sdk ) ]]; then
  echo "Usage: $0 engine|sdk" >&2
  exit 2
fi
for required in CMakeLists.txt README.md; do
  if [[ ! -f "$root/engine/$required" ]]; then
    echo "Missing engine/$required" >&2
    exit 1
  fi
done
if [[ -n "$(find "$root/engine" -type l -print)" ]]; then
  echo "Submission must not contain symbolic links" >&2
  exit 1
fi

stage="$(mktemp -d "${TMPDIR:-/tmp}/taycan-package.XXXXXX")"
trap 'rm -rf "$stage"' EXIT
mkdir -p "$root/dist"
export COPYFILE_DISABLE=1  # Do not include macOS AppleDouble metadata.
# COPYFILE_DISABLE alone does not suppress extended attributes in PAX headers.
tar_metadata_options=(--no-xattrs --no-acls)
if tar --version 2>/dev/null | grep -q bsdtar; then
  tar_metadata_options+=(--no-fflags)
fi

if [[ "$1" == engine ]]; then
  name=engine
  destination="$stage"
  entries=(engine)
else
  name=taycan_participant_sdk
  destination="$stage/$name"
  mkdir -p "$destination"
  entries=(.gitignore .clang-format CMakeLists.txt README.md package.sh include engine tests third_party)
fi

tar "${tar_metadata_options[@]}" --exclude=.git --exclude=.DS_Store --exclude='._*' \
  --exclude=build --exclude='build-*' --exclude='cmake-build-*' \
  --exclude=dist --exclude=__pycache__ --exclude='*.pyc' -cf - -C "$root" "${entries[@]}" |
  tar -xf - -C "$destination"
tar "${tar_metadata_options[@]}" -czf "$stage/$name.tar.gz" -C "$stage" "$name"
mv "$stage/$name.tar.gz" "$root/dist/$name.tar.gz"

if [[ "$1" == sdk ]]; then
  (
    cd "$root/dist"
    if command -v sha256sum >/dev/null 2>&1; then
      sha256sum "$name.tar.gz" > "$name.tar.gz.sha256"
    else
      shasum -a 256 "$name.tar.gz" > "$name.tar.gz.sha256"
    fi
  )
fi
echo "Created $root/dist/$name.tar.gz"
