"""Monitor regression checks, independent of the contestant implementation."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

from process_runner import ProcessRunner


class MonitorExitRaceTests(unittest.TestCase):
    """用可控时钟和进程状态复现退出竞态，不依赖 Linux /proc。"""

    def setUp(self):
        def patch(target, **kwargs):
            patcher = mock.patch(target, **kwargs)
            result = patcher.start()
            self.addCleanup(patcher.stop)
            return result

        self.now = 0.0
        patch('process_runner.Path.exists', return_value=True)
        self.proc = patch('process_runner.subprocess.Popen').return_value
        self.proc.poll.return_value = None
        self.proc.wait.return_value = 0
        # 手动调用 _monitor()，避免依赖真实线程调度才能触发竞态。
        patch('process_runner.threading.Thread')
        self.killpg = patch('process_runner.os.killpg')
        patch('process_runner.time.monotonic', side_effect=lambda: self.now)
        self.read_rss = patch('process_runner.read_rss')
        self.runner = ProcessRunner(['worker'], None, 256 << 20, timeout=1)
        self.runner.stop.wait = mock.Mock(side_effect=self.advance_time)

    def advance_time(self, interval):
        self.now += interval

    def missing_status(self):
        return FileNotFoundError(2, 'No such file or directory', '/proc/123/status')

    def run_delayed_exit(self, code, error):
        # 已采到 RSS，随后 /proc 消失；退出码延迟 200 ms 才可见。
        # 超过旧的 100 ms 阈值，确保固定宽限期不能通过本测试。
        self.read_rss.side_effect = [1 << 20] + [error] * 200
        self.proc.poll.side_effect = lambda: code if self.now >= 0.2 else None
        self.proc.wait.return_value = code
        self.runner._monitor()
        self.assertGreaterEqual(self.now, 0.2)
        self.assertIsNone(self.runner.reason)
        self.killpg.assert_not_called()

    def test_delayed_successful_exit(self):
        self.run_delayed_exit(0, self.missing_status())
        self.assertEqual(self.runner.finish()['status'], 'PASS')

    def test_delayed_nonzero_exit(self):
        self.run_delayed_exit(7, self.missing_status())
        with self.assertRaisesRegex(RuntimeError, 'unexpected_exit: 7'):
            self.runner.finish()

    def test_process_lookup_error_before_successful_exit(self):
        self.run_delayed_exit(0, ProcessLookupError(3, 'No such process'))
        self.assertEqual(self.runner.finish()['status'], 'PASS')

    def test_process_lookup_error_before_nonzero_exit(self):
        self.run_delayed_exit(7, ProcessLookupError(3, 'No such process'))
        with self.assertRaisesRegex(RuntimeError, 'unexpected_exit: 7'):
            self.runner.finish()

    def test_stop_during_missing_status(self):
        self.read_rss.side_effect = [1 << 20] + [self.missing_status()] * 200

        def wait(interval):
            self.advance_time(interval)
            if self.now >= 0.2:
                self.runner.stop.set()

        self.runner.stop.wait.side_effect = wait
        self.runner._monitor()
        self.assertIsNone(self.runner.reason)
        self.assertEqual(self.runner.finish()['status'], 'PASS')

    def test_rss_read_recovers_and_detects_limit(self):
        self.read_rss.side_effect = [1 << 20, self.missing_status(), 300 << 20]
        self.runner._monitor()
        self.assertEqual(self.runner.samples, 2)
        self.assertEqual(self.runner.reason, 'memory_limit')
        self.killpg.assert_called_once()

    def test_missing_status_still_times_out(self):
        self.read_rss.side_effect = self.missing_status()
        self.runner._monitor()
        self.assertEqual(self.runner.reason, 'timeout')
        self.assertGreaterEqual(self.now, self.runner.timeout)
        self.killpg.assert_called_once()

    def test_permission_error_is_not_retried(self):
        self.read_rss.side_effect = PermissionError('denied')
        self.runner._monitor()
        self.assertEqual(self.runner.reason, 'monitor_error: denied')
        self.read_rss.assert_called_once()
        self.killpg.assert_called_once()

    def test_exit_without_valid_sample_still_fails(self):
        self.read_rss.side_effect = self.missing_status()
        self.proc.poll.return_value = 0
        self.runner._monitor()
        with self.assertRaisesRegex(RuntimeError, 'no valid RSS sample'):
            self.runner.finish()


@unittest.skipUnless(Path('/proc/self/status').exists(), 'Linux /proc required')
class MonitorTests(unittest.TestCase):
    def run_worker(self, source, limit=256 << 20, timeout=5, inject=False):
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory)/'process.jsonl'
            with open(str(Path(directory)/'output'), 'w') as log:
                with ProcessRunner([sys.executable, '-c', source], log, limit,
                                   timeout, 0.005, report) as runner:
                    if inject:
                        time.sleep(0.1)
                        runner.inject_kill()
                    return runner.finish(expected_kill=inject)

    def test_success(self):
        result = self.run_worker('import time; time.sleep(.1)')
        self.assertEqual(result['status'], 'PASS')
        self.assertGreater(result['samples'], 0)

    def test_memory_limit(self):
        with self.assertRaisesRegex(RuntimeError, 'memory_limit'):
            self.run_worker('import time; x=bytearray(96*1024*1024); time.sleep(3)',
                            limit=64 << 20)

    def test_timeout(self):
        with self.assertRaisesRegex(RuntimeError, 'timeout'):
            self.run_worker('import time; time.sleep(3)', timeout=.1)

    def test_unexpected_exit(self):
        with self.assertRaisesRegex(RuntimeError, 'unexpected_exit'):
            self.run_worker('import time; time.sleep(.1); raise SystemExit(7)')

    def test_injected_kill(self):
        result = self.run_worker('import time; time.sleep(3)', inject=True)
        self.assertEqual(result['status'], 'EXPECTED_KILL')

    def test_read_error(self):
        with mock.patch('process_runner.read_rss', side_effect=PermissionError('denied')):
            with self.assertRaisesRegex(RuntimeError, 'monitor_error'):
                self.run_worker('import time; time.sleep(3)')

    def test_no_sample(self):
        with mock.patch('process_runner.read_rss', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'no valid RSS sample'):
                self.run_worker('import time; time.sleep(.1)')

    def test_memory_failure_not_accepted_as_injection(self):
        with self.assertRaisesRegex(RuntimeError, 'memory_limit'):
            self.run_worker('import time; x=bytearray(96*1024*1024); time.sleep(3)',
                            limit=64 << 20, inject=True)


if __name__ == '__main__':
    unittest.main()
