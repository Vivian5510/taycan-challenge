# This file is included by the official parent project, not configured alone.
if(NOT TARGET contest_sdk)
  message(FATAL_ERROR "Configure the SDK root; contest_sdk is supplied by the official parent")
endif()

add_library(contestant_engine STATIC engine.cc)
target_link_libraries(contestant_engine PUBLIC contest_sdk)
target_compile_features(contestant_engine PUBLIC cxx_std_17)
# Add your sources, private include directories and vendored dependencies here.
