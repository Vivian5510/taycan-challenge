#include <filesystem>
#include <mutex>
#include <unordered_map>

#include "kv_engine.h"

namespace {
// Integration example ONLY: no durability, eviction, compaction or checkpoint.
class MemoryExample final : public KVEngine {
 public:
  Status Put(const std::string& key, const std::string& value) override {
    std::lock_guard<std::mutex> lock(mu_);
    entries_[key] = value;
    return Status::OK();
  }

  Status Get(const std::string& key, std::string* value) override {
    if (!value) {
      return Status::IOError("null value output");
    }

    std::lock_guard<std::mutex> lock(mu_);
    auto it = entries_.find(key);
    if (it == entries_.end()) {
      return Status::NotFound();
    }

    *value = it->second;
    return Status::OK();
  }

  Status Delete(const std::string& key) override {
    std::lock_guard<std::mutex> lock(mu_);
    entries_.erase(key);
    return Status::OK();
  }

 private:
  std::mutex mu_;
  std::unordered_map<std::string, std::string> entries_;
};
}  // namespace

Status KVEngine::Open(const std::string& data_dir, uint64_t mem_limit_bytes,
                      KVEngine** engine) {
  if (!engine) {
    return Status::IOError("null engine output");
  }
  *engine = nullptr;

  if (data_dir.empty() || mem_limit_bytes == 0) {
    return Status::IOError("empty directory or zero memory budget");
  }

  std::error_code error;
  std::filesystem::create_directories(data_dir, error);
  if (error) {
    return Status::IOError(error.message());
  }

  *engine = new MemoryExample;
  return Status::OK();
}
