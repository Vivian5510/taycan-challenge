# 参赛实现说明

当前为内存 map 集成模板，不满足持久化、内存控制、Compaction 和 Checkpoint 要求。
