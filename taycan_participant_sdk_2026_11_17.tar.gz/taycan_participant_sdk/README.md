# Taycan 索引持久化参赛包

目标环境：**CentOS 7、Linux x86_64、GCC 8.3**。构建需要 CMake >= 3.24、Make 或 Ninja，测试需要 Python >= 3.6。
GoogleTest 1.14.0 和 gflags 2.2.2 源码随包提供。

## 编译与开发

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 4
python3 tests/run_tests.py --tests basic
```

在 `engine/engine.cc` 中实现引擎，新增源码时更新 `engine/CMakeLists.txt`。
接口位于 `include/`，公开测试位于 `tests/`。模板仅提供线程安全的内存 map，需自行实现持久化、内存控制和 Compaction；Checkpoint 为可选功能。

## 接口约定

- 实现 `KVEngine::Open` 静态工厂：目录不存在时创建，存在时恢复；失败时将 `*engine` 置空，成功后由调用方 delete。预算须大于 0。引擎的所有数据文件（包括数据、索引、WAL、元数据和临时文件）必须存放在 `Open` 指定的 `data_dir` 内，不得写入目录外或通过软链接存放到其他位置。Checkpoint 副本存放在 `CreateCheckpoint` 指定的目录内。
- 析构时引擎负责停止并回收后台线程。
- Put 覆盖旧值；Get 返回最新值，不存在时返回 NotFound；Delete 不存在的 key 返回 OK。其他错误返回 IOError。
- key/value 为可含 `\0` 的字节串，key 不允许为空。不得保留调用方的参数引用或输出指针。
- 同一实例支持多线程 Put/Get/Delete，保证单 key 线性一致性，无需跨 key 事务。同一目录只由一个活动实例访问。
- Put/Delete 返回成功前，必须完成持久化同步（如 `fsync` / `fdatasync` 或等效机制），不能仅写入内存或操作系统 page cache。保证进程崩溃或机器宕机后，已成功的写入和删除仍可恢复。读取结果须符合已成功操作的最终状态。未返回的在途操作可生效或不生效。
- Checkpoint 可选，未实现时保留默认方法。副本须对应调用期间的一致状态，可独立打开、读写，不受原目录后续修改或移除影响。目标目录须不存在且在原目录之外；允许短暂阻塞写入。

## 内存约束

`mem_limit_bytes` 是传入引擎的索引内存预算，所有公开测试默认统一为 256 MiB。Python 对所有被测进程采样 `/proc/<pid>/status` 中的 `VmRSS`，超过进程额度即终止并判为内存超限：

```text
RSS 上限 = floor(1.1 × mem_limit_bytes) + 测试程序预留额度
```

测试程序默认预留 8 MiB；mixed、compaction 另加每个 key 4 字节的参考版本数组额度。运行报告记录实际额度，不额外扣除启动 RSS。

RSS 包含进程实际驻留的堆、分配器空闲页及碎片、线程栈、文件映射、共享内存、程序和共享库页面。普通文件读写产生、未映射到进程地址空间的 page cache 不计入。外部 Python 的内存不计入，C++ 测试框架和缓冲则计入进程 RSS。

引擎只允许单进程、多线程，不得通过子进程或外部服务存储数据、执行操作。默认使用系统 malloc，也可自带分配器或内存池，但须提交必要源码，其驻留内存同样计入，不得干扰监控或规避计量。

## 测试

**提交前必须按默认验收规模通过全部必选公开测试；Checkpoint 未实现时可跳过，已实现则须通过对应测试。**
公开测试是基础验收，提交后还将进行更严格的正确性测试。通过公开测试不代表通过最终评测。

CMake 负责构建，Python 统一运行各场景并执行内存监控、超时控制、故障注入和结果汇总。
GoogleTest 和 gflags 仅供测试程序使用，引擎无需依赖它们。

```sh
# 列出场景；运行全部测试（包含 2000 万 key，耗时较长）
python3 tests/run_tests.py --list
python3 tests/run_tests.py --build-dir build

# 选择场景和 seed
python3 tests/run_tests.py --tests basic,recovery,demand_load --seed 42

# 调试参数，不改变默认验收规模
python3 tests/run_tests.py --tests mixed --num-keys 10000 --seed 42

# 崩溃恢复也通过相同入口运行
python3 tests/run_tests.py --tests crash_recovery,compaction_crash --trials 5
```

结果默认保存到临时目录 `taycan-results-*`，可通过 `--results-dir` 指定父目录。
`results.json` 汇总状态、参数、内存额度、采样峰值和耗时，各场景另存日志和 `processes.jsonl`。
失败保留数据库，成功清理数据库并保留报告。PASS / SKIP / FAIL 分别表示通过、可选功能未实现、失败；任一失败返回非零退出码。

`--timeout` 指定每个被测进程的超时秒数，默认 86400。直接运行 C++ 程序仅用于调试，不包含内存与超时验收。
监控器自测命令：`python3 tests/process_runner_test.py`（Linux）。

### 测试文件与场景

以下文件位于 `tests/`，场景名称和默认参数由 `run_tests.py` 设置。

| 文件 | 场景名称 | 默认规模及检查内容 |
|---|---|---|
| `basic_test.cc` | basic | 空 value、二进制及相似前缀 key 的独立性、长 key/value、value 缩短至空、覆盖及重复删除 |
| `sequential_test.cc` | sequential | 顺序写入 100 万 key，全量校验 |
| `random_test.cc` | random | 500 万 key，seed 决定写入遍历顺序和随机读取；最后全量校验 |
| `overwrite_test.cc` | overwrite | 10 万 key 覆盖 10 轮，每轮生成不同 value 并抽查首、中、尾 key，最后全量校验最新版本 |
| `delete_test.cc` | delete | 10 万 key，写后删除、重复删除、删除不存在的 key |
| `mixed_test.cc` | mixed | 100 万 key，300 万次混合操作；用版本数组记录参考状态并全量校验 |
| `recovery_test.cc` | recovery | 10 万 key，覆盖和删除后重新打开；继续覆盖、重新插入和删除，再次重新打开并全量校验 |
| `checkpoint_test.cc` | checkpoint | 131072 个 key，64/4096 字节 key/value；验证副本独立读写、恢复和原目录移除后的可用性；并发调用 Checkpoint 与读写接口，检查副本一致性 |
| `concurrent_test.cc` | concurrent | 不同 key 的并发读写删除；单写线程与 4 个读线程校验版本及完整 value，并检查最终状态和恢复结果 |
| `demand_load_test.cc` | demand_load | 1600 万 key，64 字节 key、128 字节 value、256 MiB 索引内存预算；写入后重新打开，4 个读线程各以两种遍历顺序全量读取，检查内存 |
| `memory_limit_test.cc` | memory_limit | 2000 万 key、256 MiB 索引内存预算；4 个线程分别处理不同 key，执行写入、覆盖、删除和旧 key 回读，线程结束后在重启前后全量校验，全程检查内存 |
| `compaction_test.cc` | compaction | 10 万 key、16 字节 key、4096 字节 value，两个写线程覆盖 10 轮并周期性删除，同时读取校验；最后一轮保留部分删除状态，检查空间回收和重新打开后数据及删除状态的正确性 |
| `crash_test.py` + `crash_worker.cc` | crash_recovery | 10 万 key，准备 1 轮写入后，执行覆盖/删除并 SIGKILL；默认 5 次独立试验，每次恢复后再次重新打开校验 |
| 同上 | compaction_crash | 10 万 key、4096 字节 value，准备 10 轮覆盖/删除后执行相同崩溃协议 |

正式性能测试数据和评分程序不随包提供，公开测试不计性能分。

### 公共工具与数据生成

| 文件 | 用途 |
|---|---|
| `test_options.h/.cc` | gflags 参数定义、合法性检查和本次参数输出 |
| `test_main.cc` | GoogleTest 和 gflags 初始化，未知参数或非法参数返回非零退出码 |
| `workload.h` | 固定算法根据 seed、key_id、version 生成数据，保证不同 key_id 的 key 唯一；不依赖标准库随机分布实现 |
| `test_helper.h` | 临时目录、引擎打开、复用读写缓冲和返回详细错误的校验函数 |
| `run_tests.py` | 统一入口、场景默认参数和结果汇总 |
| `process_runner.py` | Linux 进程 RSS 采样、超时、终止及进程报告 |
| `process_runner_test.py` | 监控器自身的正常、超限、超时及故障分类回归检查 |
| `crash_test.py` | 准备、故障注入和两次恢复校验，复用同一监控器 |

测试数据由 `seed`、`key_id`、`version` 确定，不保存完整 value。version 仅用于生成和校验数据，不要求引擎支持多版本；参考版本 0 表示 key 不存在。错误信息包含 seed、key_id 和预期版本，便于复现。

`key_mode=random` 生成唯一伪随机 key，`key_mode=sequential` 生成按字节排序递增的 key；key 内容模式与访问顺序独立。
常用 C++ 参数包括 `--seed`、`--num_keys`、`--key_mode`、`--key_size`、`--value_size`、`--mem_limit_bytes`、`--rounds`，完整说明见 `--help`。

### 内存与空间判定

按需加载和内存限制测试检查受限内存下的读写、恢复行为。demand_load 测试的原始 key 总量约 977 MiB，`mem_limit_bytes` 为 256 MiB。

所有场景默认每 2 ms 采样一次 RSS（`--sample-interval-ms`），覆盖进程启动、恢复、运行和销毁。崩溃测试的各个 worker 进程分别监控。无法获取有效样本、内存超限、超时或意外退出均判失败。

Compaction 在停止写入、保持引擎打开的情况下，最多等待 120 秒，要求数据目录内所有普通文件的逻辑长度总和满足：

```text
目录大小 ≤ 3 × 最终存活 KV 的逻辑字节数 + 16 MiB
```

索引、WAL 和临时文件均计入，不限定具体 Compaction 算法。可用 `--space_ratio`、`--space_slack_bytes`、`--reclaim_timeout_seconds` 调试，正式验收以官方参数为准。

### 崩溃恢复协议

Python 逐条发送操作，worker 在 Put/Delete 成功返回后报告 ACK，Python 收到 ACK 后再发送下一条。SIGKILL 后读完管道中的完整 ACK，确定已完成操作，最多保留一条结果未知的操作。

恢复后全量校验：已确认操作必须保留，未确认操作允许生效或未生效，不接受其他旧值或损坏值。第二次重新打开必须与第一次恢复结果一致。
默认执行 5 次独立试验，覆盖命令尚未执行、立即 kill 和随机延时 kill；失败保留数据与日志。测试模拟进程崩溃，不模拟断电，也不保证 kill 恰好发生在内部 Compaction 期间。

## 提交

填写 `engine/README.md`，然后打包：

```sh
./package.sh engine
```

提交 **`dist/engine.tar.gz`**，根目录为 `engine/`。脚本只打包，不编译或运行测试。

- 保留 `contestant_engine` 静态库 target，链接官方提供的 `contest_sdk`，不包含 main。
- 只修改 `engine/`，使用 target 级 CMake 配置，不修改官方接口、测试或全局编译设置。
- 提交全部必要源码及依赖许可证，确保离线编译；不能依赖绝对路径、软链接、目录外文件或预编译产物。
- 打包忽略 `.git`、`.DS_Store`、`build`、`build-*`、`cmake-build-*`、`dist`，必要源码不能放在这些目录。

提交后，评测方将结合测试结果审查代码，确认实现符合赛题和接口要求，包括数据及索引按要求实际落盘、恢复逻辑完整、内存使用合规等。
针对测试数据硬编码结果、伪造持久化、绕过测试或内存监控等作弊行为，一经确认，提交及成绩均判定无效。

出题方生成完整参赛包：`./package.sh sdk`，产物位于 `dist/`。
